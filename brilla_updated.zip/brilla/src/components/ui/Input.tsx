import React from 'react';
import { cn } from '@/lib/utils';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, type, ...props }, ref) => {
    return (
      <div className="w-full space-y-2">
        {label && (
          <label className="block text-taupe-elegant font-cormorant text-sm font-medium">
            {label}
          </label>
        )}
        <input
          type={type}
          className={cn(
            "w-full bg-blanc-casse border-b-2 border-taupe-elegant px-4 py-2 focus:outline-none focus:border-or-sophistique transition-all duration-300",
            error && "border-bordeaux-profond",
            className
          )}
          ref={ref}
          {...props}
        />
        {error && (
          <p className="text-bordeaux-profond text-xs mt-1">{error}</p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

export { Input };
