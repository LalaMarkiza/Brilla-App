import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const buttonVariants = cva(
  'inline-flex items-center justify-center rounded-sm text-sm font-medium transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-or-sophistique focus:ring-opacity-50 disabled:opacity-50 disabled:pointer-events-none',
  {
    variants: {
      variant: {
        primary: 'bg-bordeaux-profond text-blanc-casse hover:opacity-90',
        secondary: 'bg-or-sophistique text-blanc-casse hover:opacity-90',
        outline: 'border-2 border-or-sophistique text-or-sophistique hover:bg-or-sophistique hover:text-blanc-casse',
        ghost: 'bg-transparent text-noir-profond hover:bg-sable-dore/20',
        link: 'bg-transparent text-or-sophistique underline-offset-4 hover:underline',
      },
      size: {
        default: 'h-10 px-6 py-3',
        sm: 'h-8 px-4 py-2 text-xs',
        lg: 'h-12 px-8 py-4 text-base',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'default',
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);

Button.displayName = 'Button';

export { Button, buttonVariants };
