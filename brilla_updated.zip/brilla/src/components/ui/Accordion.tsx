import React from 'react';
import { cn } from '@/lib/utils';
import { ChevronDown } from 'lucide-react';

interface AccordionProps {
  items: {
    title: string;
    content: React.ReactNode;
  }[];
  className?: string;
}

export function Accordion({ items, className }: AccordionProps) {
  const [openIndex, setOpenIndex] = React.useState<number | null>(null);

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className={cn("w-full space-y-2", className)}>
      {items.map((item, index) => (
        <div 
          key={index} 
          className="border-b border-or-sophistique/20 last:border-b-0"
        >
          <button
            onClick={() => toggleItem(index)}
            className="flex w-full justify-between items-center py-4 text-left font-cormorant text-lg font-medium text-taupe-elegant hover:text-bordeaux-profond transition-colors"
          >
            <span>{item.title}</span>
            <ChevronDown 
              className={cn(
                "h-5 w-5 text-or-sophistique transition-transform duration-200",
                openIndex === index && "transform rotate-180"
              )} 
            />
          </button>
          <div 
            className={cn(
              "overflow-hidden transition-all duration-300 ease-in-out",
              openIndex === index ? "max-h-96 opacity-100 pb-4" : "max-h-0 opacity-0"
            )}
          >
            <div className="text-taupe-elegant">
              {item.content}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
