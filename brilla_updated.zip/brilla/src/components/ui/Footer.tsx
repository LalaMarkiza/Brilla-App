import React from 'react';
import { cn } from '@/lib/utils';

interface FooterProps extends React.HTMLAttributes<HTMLElement> {
  links?: {
    title: string;
    items: {
      label: string;
      href: string;
    }[];
  }[];
  socialLinks?: {
    icon: React.ReactNode;
    href: string;
  }[];
  bottomText?: string;
}

export function Footer({ 
  className, 
  links = [], 
  socialLinks = [],
  bottomText = "© 2025 BRILLA. Tous droits réservés.",
  ...props 
}: FooterProps) {
  return (
    <footer
      className={cn(
        "bg-sable-dore/30 border-t border-or-sophistique/20 pt-12 pb-6",
        className
      )}
      {...props}
    >
      <div className="container mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <div className="flex flex-col space-y-4">
              <span className="text-3xl font-playfair font-bold text-bordeaux-profond">
                BRILLA
              </span>
              <p className="text-taupe-elegant max-w-xs">
                Une application de transformation santé et bien-être de catégorie luxe, destinée à offrir une expérience exceptionnelle.
              </p>
              
              {/* Social Links */}
              {socialLinks.length > 0 && (
                <div className="flex space-x-4 mt-4">
                  {socialLinks.map((link, index) => (
                    <a
                      key={index}
                      href={link.href}
                      className="text-taupe-elegant hover:text-bordeaux-profond transition-colors"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {link.icon}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          {/* Footer Links */}
          {links.map((section, sectionIndex) => (
            <div key={sectionIndex} className="flex flex-col space-y-4">
              <h3 className="font-cormorant text-xl font-semibold text-bordeaux-profond">
                {section.title}
              </h3>
              <ul className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <li key={itemIndex}>
                    <a
                      href={item.href}
                      className="text-taupe-elegant hover:text-bordeaux-profond transition-colors"
                    >
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        {/* Bottom Text */}
        <div className="mt-12 pt-6 border-t border-or-sophistique/10 text-center text-taupe-elegant text-sm">
          {bottomText}
        </div>
      </div>
    </footer>
  );
}
