"use client";

import React from 'react';
import { Navbar } from '@/components/ui/Navbar';
import { Footer } from '@/components/ui/Footer';
import { SubscriptionForm } from '@/components/subscription/SubscriptionForm';
import { useAuth } from '@/lib/auth';
import { useRouter } from 'next/navigation';

export default function Pricing() {
  const { user, isAuthenticated } = useAuth();
  const router = useRouter();
  
  // Gérer la fin du processus d'abonnement
  const handleSubscriptionComplete = (plan: string) => {
    // Dans une vraie application, cette logique serait gérée par le backend
    // Ici, nous simulons simplement la redirection vers le tableau de bord
    router.push('/dashboard');
  };

  // Données de navigation
  const menuItems = [
    { label: 'Accueil', href: '/' },
    { label: 'À propos', href: '/about' },
    { label: 'Fonctionnalités', href: '/features' },
    { label: 'Tarifs', href: '/pricing' },
  ];

  // Contenu du footer
  const footerLinks = [
    {
      title: 'BRILLA',
      items: [
        { label: 'À propos', href: '/about' },
        { label: 'Notre équipe', href: '/team' },
        { label: 'Témoignages', href: '/testimonials' },
        { label: 'Carrières', href: '/careers' },
        { label: 'Contact', href: '/contact' }
      ]
    },
    {
      title: 'Services',
      items: [
        { label: 'Nutrition Elite', href: '/features/nutrition' },
        { label: 'Complémentation', href: '/features/supplements' },
        { label: 'Activité Physique', href: '/features/activity' },
        { label: 'Suivi Médical', href: '/features/medical' },
        { label: 'Optimisation Hormonale', href: '/features/hormonal' }
      ]
    },
    {
      title: 'Ressources',
      items: [
        { label: 'Blog', href: '/blog' },
        { label: 'FAQ', href: '/faq' },
        { label: 'Support', href: '/support' },
        { label: 'Tutoriels', href: '/tutorials' },
        { label: 'Communauté', href: '/community' }
      ]
    }
  ];

  return (
    <main className="min-h-screen bg-blanc-casse">
      {/* Navigation */}
      <Navbar menuItems={menuItems} />

      {/* Contenu principal */}
      <div className="container mx-auto py-16 px-6">
        <SubscriptionForm onSubscriptionComplete={handleSubscriptionComplete} />
      </div>

      {/* Footer */}
      <Footer links={footerLinks} />
    </main>
  );
}
