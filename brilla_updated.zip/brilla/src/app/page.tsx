"use client";

import React from 'react';
import { Navbar } from '@/components/ui/Navbar';
import { Footer } from '@/components/ui/Footer';
import { HeroSection } from '@/components/sections/HeroSection';
import { FeaturesGrid } from '@/components/sections/FeaturesGrid';
import { TestimonialsSection } from '@/components/sections/TestimonialsSection';
import { PricingSection } from '@/components/sections/PricingSection';
import { CTASection } from '@/components/sections/CTASection';

export default function Home() {
  // Données de navigation
  const menuItems = [
    { label: 'Accueil', href: '/' },
    { label: 'À propos', href: '/about' },
    { label: 'Fonctionnalités', href: '/features' },
    { label: 'Tarifs', href: '/pricing' },
  ];

  // Contenu du footer
  const footerLinks = [
    {
      title: 'BRILLA',
      items: [
        { label: 'À propos', href: '/about' },
        { label: 'Notre équipe', href: '/team' },
        { label: 'Témoignages', href: '/testimonials' },
        { label: 'Carrières', href: '/careers' },
        { label: 'Contact', href: '/contact' }
      ]
    },
    {
      title: 'Services',
      items: [
        { label: 'Nutrition Elite', href: '/features/nutrition' },
        { label: 'Complémentation', href: '/features/supplements' },
        { label: 'Activité Physique', href: '/features/activity' },
        { label: 'Suivi Médical', href: '/features/medical' },
        { label: 'Optimisation Hormonale', href: '/features/hormonal' }
      ]
    },
    {
      title: 'Ressources',
      items: [
        { label: 'Blog', href: '/blog' },
        { label: 'FAQ', href: '/faq' },
        { label: 'Support', href: '/support' },
        { label: 'Tutoriels', href: '/tutorials' },
        { label: 'Communauté', href: '/community' }
      ]
    }
  ];

  return (
    <main className="min-h-screen bg-blanc-casse">
      {/* Navigation */}
      <Navbar menuItems={menuItems} />

      {/* Contenu principal */}
      <div>
        {/* Section héroïque */}
        <HeroSection />

        {/* Grille de fonctionnalités */}
        <FeaturesGrid />

        {/* Section de témoignages */}
        <TestimonialsSection />

        {/* Section de tarification */}
        <PricingSection />

        {/* Section d'appel à l'action */}
        <CTASection />
      </div>

      {/* Footer */}
      <Footer links={footerLinks} />
    </main>
  );
}
