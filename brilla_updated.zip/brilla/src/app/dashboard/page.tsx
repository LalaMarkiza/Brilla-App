"use client";

import React, { useState } from 'react';
import { Navbar } from '@/components/ui/Navbar';
import { Footer } from '@/components/ui/Footer';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/Button';
import { ProgressDashboard } from '@/components/dashboard/ProgressDashboard';
import { NutritionDashboard } from '@/components/dashboard/NutritionDashboard';
import { ActivityDashboard } from '@/components/dashboard/ActivityDashboard';
import { SupplementDashboard } from '@/components/dashboard/SupplementDashboard';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  // Données de navigation
  const menuItems = [
    { label: 'Accueil', href: '/' },
    { label: 'Tableau de bord', href: '/dashboard', isPremium: true },
    { label: 'Nutrition', href: '/dashboard?tab=nutrition', isPremium: true },
    { label: 'Activité', href: '/dashboard?tab=activity', isPremium: true },
    { label: 'Compléments', href: '/dashboard?tab=supplements', isPremium: true },
    { label: 'Profil', href: '/dashboard/profile', isPremium: true },
  ];

  // Changer d'onglet
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    // Mettre à jour l'URL sans rechargement de page
    window.history.pushState({}, '', `/dashboard?tab=${tab}`);
  };

  // Déterminer le contenu à afficher en fonction de l'onglet actif
  const renderContent = () => {
    switch (activeTab) {
      case 'nutrition':
        return <NutritionDashboard />;
      case 'activity':
        return <ActivityDashboard />;
      case 'supplements':
        return <SupplementDashboard />;
      case 'progress':
        return <ProgressDashboard />;
      default:
        return (
          <div className="space-y-8">
            <div>
              <h1 className="font-playfair text-3xl md:text-4xl font-semibold mb-4 text-bordeaux-profond">
                Tableau de bord
              </h1>
              <p className="text-taupe-elegant max-w-3xl">
                Bienvenue dans votre espace personnel BRILLA. Voici un aperçu de votre progression et de vos recommandations personnalisées.
              </p>
            </div>

            {/* Statut de l'abonnement */}
            <div className="mb-10 p-6 bg-premium-gradient text-blanc-casse rounded-sm shadow-premium">
              <h2 className="font-cormorant text-2xl font-semibold mb-2">
                Votre abonnement: {user?.subscription === 'premium' ? 'Premium' : user?.subscription === 'elite' ? 'Élite' : 'Essentiel'}
              </h2>
              <p className="mb-4 opacity-90">
                {user?.subscription === 'none' 
                  ? "Vous n'avez pas encore d'abonnement actif. Découvrez nos formules pour accéder à toutes les fonctionnalités." 
                  : "Profitez de toutes les fonctionnalités exclusives de votre abonnement."}
              </p>
              {user?.subscription === 'none' && (
                <Button variant="secondary" asChild>
                  <a href="/pricing">Voir les formules</a>
                </Button>
              )}
            </div>

            {/* Aperçu des modules */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Carte Nutrition */}
              <div className="bg-blanc-casse border border-or-sophistique/10 rounded-sm p-6 shadow-elegant">
                <h3 className="font-cormorant text-xl font-semibold mb-3 text-bordeaux-profond">
                  Nutrition
                </h3>
                <p className="text-taupe-elegant mb-4">
                  Découvrez vos recommandations nutritionnelles personnalisées et vos recettes du jour.
                </p>
                <Button variant="outline" size="sm" onClick={() => handleTabChange('nutrition')}>
                  Voir les détails
                </Button>
              </div>

              {/* Carte Activité */}
              <div className="bg-blanc-casse border border-or-sophistique/10 rounded-sm p-6 shadow-elegant">
                <h3 className="font-cormorant text-xl font-semibold mb-3 text-bordeaux-profond">
                  Activité physique
                </h3>
                <p className="text-taupe-elegant mb-4">
                  Accédez à votre programme d'activité personnalisé et suivez votre progression.
                </p>
                <Button variant="outline" size="sm" onClick={() => handleTabChange('activity')}>
                  Voir les détails
                </Button>
              </div>

              {/* Carte Compléments */}
              <div className="bg-blanc-casse border border-or-sophistique/10 rounded-sm p-6 shadow-elegant">
                <h3 className="font-cormorant text-xl font-semibold mb-3 text-bordeaux-profond">
                  Complémentation
                </h3>
                <p className="text-taupe-elegant mb-4">
                  Consultez votre protocole de complémentation personnalisé pour optimiser votre santé.
                </p>
                <Button variant="outline" size="sm" onClick={() => handleTabChange('supplements')}>
                  Voir les détails
                </Button>
              </div>

              {/* Carte Progression */}
              <div className="bg-blanc-casse border border-or-sophistique/10 rounded-sm p-6 shadow-elegant">
                <h3 className="font-cormorant text-xl font-semibold mb-3 text-bordeaux-profond">
                  Suivi de progression
                </h3>
                <p className="text-taupe-elegant mb-4">
                  Visualisez l'évolution de vos métriques clés au fil du temps.
                </p>
                <Button variant="outline" size="sm" onClick={() => handleTabChange('progress')}>
                  Voir les détails
                </Button>
              </div>

              {/* Carte Profil */}
              <div className="bg-blanc-casse border border-or-sophistique/10 rounded-sm p-6 shadow-elegant">
                <h3 className="font-cormorant text-xl font-semibold mb-3 text-bordeaux-profond">
                  Profil
                </h3>
                <p className="text-taupe-elegant mb-4">
                  Gérez vos informations personnelles, vos préférences et votre abonnement.
                </p>
                <Button variant="outline" size="sm" asChild>
                  <a href="/dashboard/profile">Gérer mon profil</a>
                </Button>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <ProtectedRoute>
      <main className="min-h-screen bg-blanc-casse">
        {/* Navigation */}
        <Navbar 
          menuItems={menuItems} 
          rightContent={
            <div className="flex items-center space-x-4">
              <span className="text-taupe-elegant">
                Bonjour, {user?.name}
              </span>
              <Button variant="outline" size="sm" onClick={logout}>
                Déconnexion
              </Button>
            </div>
          }
        />

        {/* Contenu principal */}
        <div className="container mx-auto py-12 px-6">
          {/* Onglets de navigation */}
          {activeTab !== 'overview' && (
            <div className="mb-8">
              <div className="flex flex-wrap border-b border-or-sophistique/20">
                <button 
                  className={`px-4 py-2 font-cormorant text-lg transition-colors ${activeTab === 'overview' ? 'border-b-2 border-bordeaux-profond text-bordeaux-profond' : 'text-taupe-elegant hover:text-bordeaux-profond'}`}
                  onClick={() => handleTabChange('overview')}
                >
                  Aperçu
                </button>
                <button 
                  className={`px-4 py-2 font-cormorant text-lg transition-colors ${activeTab === 'nutrition' ? 'border-b-2 border-bordeaux-profond text-bordeaux-profond' : 'text-taupe-elegant hover:text-bordeaux-profond'}`}
                  onClick={() => handleTabChange('nutrition')}
                >
                  Nutrition
                </button>
                <button 
                  className={`px-4 py-2 font-cormorant text-lg transition-colors ${activeTab === 'activity' ? 'border-b-2 border-bordeaux-profond text-bordeaux-profond' : 'text-taupe-elegant hover:text-bordeaux-profond'}`}
                  onClick={() => handleTabChange('activity')}
                >
                  Activité
                </button>
                <button 
                  className={`px-4 py-2 font-cormorant text-lg transition-colors ${activeTab === 'supplements' ? 'border-b-2 border-bordeaux-profond text-bordeaux-profond' : 'text-taupe-elegant hover:text-bordeaux-profond'}`}
                  onClick={() => handleTabChange('supplements')}
                >
                  Compléments
                </button>
                <button 
                  className={`px-4 py-2 font-cormorant text-lg transition-colors ${activeTab === 'progress' ? 'border-b-2 border-bordeaux-profond text-bordeaux-profond' : 'text-taupe-elegant hover:text-bordeaux-profond'}`}
                  onClick={() => handleTabChange('progress')}
                >
                  Progression
                </button>
              </div>
            </div>
          )}

          {/* Contenu dynamique */}
          {renderContent()}
        </div>

        {/* Footer */}
        <Footer />
      </main>
    </ProtectedRoute>
  );
}
